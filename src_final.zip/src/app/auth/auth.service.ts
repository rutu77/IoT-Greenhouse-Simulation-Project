import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Role } from './role.enum';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private router:Router) {
    localStorage.setItem('isLoggedIn','false');
   }

  // userLogin(){
  //   localStorage.setItem('isLoggedIn','true')
  //   localStorage.setItem('role',Role.Customer);
  //   this.router.navigate(['/'])
  // }

  Login(role:Role){
    localStorage.setItem('isLoggedIn','true')
    localStorage.setItem('role',JSON.stringify(Role[role]));
    this.router.navigate(['/'])
  }


  isUserAuthenticated(){
    const isLoggedIn=localStorage.getItem('isLoggedIn')==='true';
    if(!isLoggedIn){
      return false;
    }
    else{
      return true;
    }
  }

}
