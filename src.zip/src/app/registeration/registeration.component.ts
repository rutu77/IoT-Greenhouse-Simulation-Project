import { Component } from '@angular/core';

@Component({
  selector: 'app-registeration',
  standalone: false,
  
  templateUrl: './registeration.component.html',
  styleUrl: './registeration.component.css'
})
export class RegisterationComponent {
  user={id:"",username:"",email:"",password:"",phone:"",address:""};

  onSubmit(form:any){
    console.log("Submitted:",form.value);
    form.reset();
  }
}
