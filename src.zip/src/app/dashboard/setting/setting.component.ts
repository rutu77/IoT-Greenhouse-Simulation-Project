import { Component } from '@angular/core';

@Component({
  selector: 'app-setting',
  standalone: false,
  
  templateUrl: './setting.component.html',
  styleUrl: './setting.component.css'
})
export class SettingComponent {

}
