import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Role } from './role.enum';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private router:Router) { }

  //  private role:string='Manager'
  Login(role:Role){
    localStorage.setItem('isLoggedIn','true')
    localStorage.setItem('role',JSON.stringify(Role[role]));
    this.router.navigate(['user/dashboard'])
  }

  getRole():Role|null{
    let isLoggedIn=  localStorage.getItem('isLoggedIn')==='true';
    let role= localStorage.getItem('role');
    if(isLoggedIn && role){
      return role as Role;
    }
    return null;
  }


  isUserAuthenticated(role:Role){
    const isLoggedIn=localStorage.getItem('isLoggedIn')==='true';
    if(!isLoggedIn){
      alert("Login first!")
      this.router.navigate(['user/login'])
      return false;
    }
    
    if(role===Role.Customer){
      return true;
    }
    else{
      alert("You don't have access")
      return false;
    }
  }
}
