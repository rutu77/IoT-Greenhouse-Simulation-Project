import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot} from '@angular/router';
import { AuthService } from './auth.service';
import { Role } from './role.enum';

// import { AuthService } from './auth.service';
@Injectable({
  providedIn:"root"
})

export class CustomerGuard implements CanActivate{
  constructor(private authService:AuthService){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean{
    return this.authService.isUserAuthenticated(Role.Customer)
}
}
  //   const value= localStorage.getItem('isLoggedIn');

  //   if(value!=='true'){
  //     return false;
  //   }
  //   const role=localStorage.getItem('role');

  //   if(role!=='Manager'){
  //     return true;
  //   }

  //   this.router.navigate(['/user/login'])
  //   return false;
  // }

