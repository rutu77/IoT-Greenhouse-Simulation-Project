export enum Role{
    Admin="Admin",
    Manager="Manager",
    Customer="Customer"
}