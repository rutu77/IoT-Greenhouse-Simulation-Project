import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, GuardResult, MaybeAsync, Router, RouterStateSnapshot} from '@angular/router';
import { Role } from './role.enum';
import { AuthService } from './auth.service';

@Injectable({
  providedIn:"root"
})

export class AdminGuard implements CanActivate{
  constructor(private router:Router, private auth:AuthService){}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean{
    return this.auth.isUserAuthenticated(Role.Admin)
  }
  //   const value= localStorage.getItem('isLoggedIn');

  //   if(value!=='true'){
  //     return false;
  //     alert("Only Admin can Access")
  //   }
  //   const role=localStorage.getItem('role');

  //   if(role==='Admin'){
  //     return true;
  //   }

  //   this.router.navigate(['/'])
  //   return false;
  // }
}
