import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custom',
  standalone: false
})
export class CustomPipe implements PipeTransform {
  transform(str:string): string {
    return str.split('').reverse().join('')
  }

}
