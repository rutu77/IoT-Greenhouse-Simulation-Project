import { Component } from '@angular/core';

@Component({
  selector: 'app-no-found',
  standalone: false,
  
  templateUrl: './no-found.component.html',
  styleUrl: './no-found.component.css'
})
export class NoFoundComponent {

}
