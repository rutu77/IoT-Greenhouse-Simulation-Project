import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationCancel, Router, Event } from '@angular/router';

@Component({
  selector: 'app-form',
  standalone: false,
  
  templateUrl: './form.component.html',
  styleUrl: './form.component.css'
})
export class FormComponent implements OnInit{
  userData:any;
  constructor(private route:ActivatedRoute){}
  ngOnInit(){
    this.route.data.subscribe(data=>{
      this.userData=data['user'];
      console.log('Resolved User Data:',this.userData);
    })
  }
}

