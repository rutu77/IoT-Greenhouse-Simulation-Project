import { Component } from '@angular/core';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Angular_6_2';
  // pipes
  // price=50;
  // today=new Date()
  // name="Hello";
  // data$: Observable<string>= of("Hello World")



  //RxJS
  //example 1
  // myObservable = new Observable<string>(observer => {
  //   observer.next("Hello");
  //   observer.next("Rutuja!");
  //   observer.next("How are you.");
  //   observer.complete();
  // });
  
  // constructor(){
  //   this.myObservable.subscribe(value => console.log(value));
  // }

  //example 2
  // observer={
  //   next:(value:any)=> console.log("Received", value),
  //   error:(err:any)=>console.log("error",err),
  //   complete:()=>console.log("Done!")
  // }
  // observable= new Observable<number>(obs=>{
  //   obs.next(1),
  //   obs.next(2),
  //   obs.complete()
  // })

  // constructor(){
  //   this.observable.subscribe(this.observer);
  // }

  //example 3
  // myObservable = new Observable<string>(observer => {
  //   setTimeout(()=>observer.next("Hello"),1000);
  //   setTimeout(()=>observer.next("Rutuja!"),2000);
  //   setTimeout(()=>observer.complete(),3000);

  // });
  
  // constructor(){
  //   this.myObservable.subscribe(value => console.log(value));
  // }

  //example 4
  // observable= new Observable<number>(obs=>{
  //   setTimeout(()=>obs.next(1),1000);
  //   setTimeout(()=>obs.next(2),2000);
  //   setTimeout(()=>obs.complete(),3000);
  // })

  // constructor(){
  // const subscription=this.observable.subscribe({next:(value:any)=> console.log("Received", value),
  //   error:(err:any)=>console.log("error",err),
  //   complete:()=>console.log("Done!")}
  // );

  // setTimeout(()=>{subscription.unsubscribe(),
  //   console.log("Unsubscribed!")
  // },4000)
  // }

  //example 5
  orderStatusObservable= new Observable<string>
  subscription:any;
  statuses: string[] = [];
  flag:boolean=false

  customObserver = {
    next: (status: string) => {
      console.log("Order Status: ", status);
      this.statuses.push(status);
    },
    error: (err: any) => {
      console.log("Error: ", err);
      this.statuses.push(`Error: ${err}`);
    },
    complete: () => {
      console.log("Order tracking completed!");
      this.statuses.push("Order tracking completed!");
    }
  };

  ngOnInit() {
    this.orderStatusObservable = new Observable(observer => {
      observer.next('Order placed');
      setTimeout(() => observer.next("Shipped"), 2000);
      setTimeout(() => observer.next("Out for Delivery"), 4000);
      setTimeout(() => observer.next("Delivered"), 6000);
      setTimeout(() => observer.complete(), 6000);
    });

    this.subscription = this.orderStatusObservable.subscribe(this.customObserver);

//       setTimeout(() => {
//         this.subscription.unsubscribe();
//         console.log("Unsubscribed!");
//         this.statuses.push("Unsubscribed!");
//       }, 8000);
// }

//   unsubscribe() {
//     this.subscription.unsubscribe();
//     console.log("Unsubscribed!");
//     this.statuses.push("Unsubscribed!");
//   }
// }

      setTimeout(() => {
        this.subscription.unsubscribe();
        console.log("Unsubscribed!");
        this.statuses.push("Unsubscribed!");
      }, 8000);
}

  unsubscribe() {
    this.subscription.unsubscribe();
    console.log("Unsubscribed!");
    this.statuses.push("Unsubscribed!");
  }
}

