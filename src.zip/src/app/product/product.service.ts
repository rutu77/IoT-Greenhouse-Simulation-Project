import { Injectable } from '@angular/core';

export interface ProductItem {
  id: number;
  name: string;
  price: number;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products: ProductItem[] = [
    { id: 1, name: 'Laptop', price: 40000 },
    { id: 2, name: 'SmartPhone', price: 20000 }
  ];

  private new:any;
  constructor() { }

  getProducts(): ProductItem[] {
    return this.products;
  }

  addnewProduct() {
    this.products.push({id:0,name:"new product",price:0});
  }

  removeProduct(product: ProductItem): void {
    const index = this.products.findIndex((p) => p.id === product.id);
    if (index > -1) {
      this.products.splice(index, 1);
    }
  }
}
