import { Injectable } from '@angular/core';

export interface ProductItem{
  id:number,
  name:string,
  price:number
}
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private products: ProductItem[] = [
    {id:1,name:'Laptop',price:40000},
    {id:2,name:'SmartPhone',price:20000}, 
  ];

  constructor() { }

  private selectedProduct:ProductItem|null=null;

  getProducts(): ProductItem[] {
    return this.products;
  }

  setSeletedProduct(product:ProductItem){
    this.selectedProduct=product;
  }

  getSeletedProduct():ProductItem|null{
    return this.selectedProduct;
  }
}
