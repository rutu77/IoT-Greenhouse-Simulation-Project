import { Component } from '@angular/core';
import { ProductItem, ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  standalone: false,
  
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {
  products:ProductItem[]
  constructor(private pservice:ProductService, private router:Router){
    this.products=this.pservice.getProducts();
  }

  viewProduct(product:ProductItem){
    this.pservice.setSeletedProduct(product);
    this.router.navigate(['/productdetails'])
  }
}
