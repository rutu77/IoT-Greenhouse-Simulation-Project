import { Component } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-details',
  standalone: false,
  
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent {
  // constructor(private productservice:ProductService){}
  // product={name:"product 1",id:101}
  // addproduct(){
  //   this.productservice.addProduct(this.product);
  // }
  // getProductDetails(){
  //   this.productservice.getProducts();
  // }

}
