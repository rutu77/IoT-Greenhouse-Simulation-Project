// import { CanActivateFn } from '@angular/router';
// export const authguardGuard: CanActivateFn = (route, state) => {
//   return true;
// };

import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, CanDeactivate, GuardResult, MaybeAsync, Resolve, Router, RouterStateSnapshot } from "@angular/router";
import { GuardService } from "./guardservice.service";
import { Observable, of } from "rxjs";

@Injectable(
  {providedIn:'root'}
)
export class authguardGuard implements CanActivate, CanActivateChild, CanDeactivate<any>, Resolve<any>{
  constructor(private router:Router,private guardservice:GuardService){}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    //  -->without service 
    const isAuthenticated= localStorage.getItem('loggedIn')==='true'
    if(!isAuthenticated){
      alert('Login first!');
      this.router.navigate(['/login']);
      return false;
    }
    return true;

    //-->With services
    // const isLoggedIn = this.guardservice.isLoggedIn();
    // if (!isLoggedIn) {
    //   alert('Login first!');
    //   this.router.navigate(['/login']);
    // }
    // return isLoggedIn;
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean{
    const role= localStorage.getItem('role');
    const isAuthenticated= localStorage.getItem('loggedIn')==='true'
    if(!isAuthenticated){
      alert('Login first!');
      this.router.navigate(['/login'])
    }
    else if(role!=='Admin'){
        alert('Only admin can access');
        return false;
    }
    return true;
  }

  canDeactivate(component: any, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState: RouterStateSnapshot): any {
    return alert("Leave without saving?")
  }

  resolve(): Observable<any>{
    const userdata={id:1,name:'abc',email:'abc@gmail.com'};
    return of(userdata);
  }
}